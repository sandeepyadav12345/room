﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace EmployeeManagement.Models
{
    public class Employee
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "the field is required")]
        [StringLength(8, ErrorMessage = "Name length cannot be more than 8")]
        public string Name { get; set; }


        
        [Required(ErrorMessage = "the field is required")]
        [Display(Name = "Office Email")]
        public string Email { get; set; }
        
        [Required(ErrorMessage = "the field is required")]
        public string Department { get; set; }
        

    }
}
