﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EmployeeManagement.Models;
using EmployeeManagement.Repository.Interface;
using EmployeeManagement.ViewModel;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace EmployeeManagement.Controllers
{
    public class EmployeeController : Controller
    {
        private IEmployeeRepository _IEmployeeRepo;
        public EmployeeController(IEmployeeRepository IEmployeeRepo)
        {
            _IEmployeeRepo = IEmployeeRepo;

            // GET: /<controller>/
        }
            public ViewResult Details()
            {
            Employee em = _IEmployeeRepo.GetEmployee(2);
            EmployeeViewModel vm = new EmployeeViewModel();
            vm.Employee = em;
            vm.Title = "I am boy";
                return View(vm);
            }
        public ViewResult AllDetails()
        {
           List<Employee> gm = _IEmployeeRepo.GetAllEmployee();
            return View(gm);
        }
        [HttpGet]
        public ViewResult Create()
        {
            return View();
        }
        [HttpPost]

        public IActionResult Create(Employee employee)
        {
            if (ModelState.IsValid)
            {
                Employee emp = _IEmployeeRepo.Add(employee);
                return RedirectToAction("Details", new { Id = emp.Id });
            }
            return View();

        }
        public ViewResult Details(int id)
        {
            Employee em = _IEmployeeRepo.GetEmployee(id);
            return View(em);
        }

        public ActionResult Foo()
        {
            return View();
        }
        }
    }

