﻿using System;
using EmployeeManagement.Models;

namespace EmployeeManagement.ViewModels
{
    public class EmployeeViewModel
    {
        public Employee Employee { get; set; }
        
        public string Tittle { get; set; }
    }
}
