﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EmployeeManagement.ViewModels;
using EmployeeManagement.Models;
using EmployeeManagement.Repository.Interface;

using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using System.IO;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace EmployeeManagement.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly IEmployeeRepository _IEmployeeRepo;
        private readonly IHostingEnvironment hostingEnvironment;
       

        public EmployeeController(IEmployeeRepository IEmployeeRepo,IHostingEnvironment hostingEnvironment)
        {
            _IEmployeeRepo = IEmployeeRepo;
            this.hostingEnvironment = hostingEnvironment;

            // GET: /<controller>/
        }
         //   public ViewResult Details()
           // {
            //Employee em = _IEmployeeRepo.GetEmployee(2);
            //EmployeeViewModel vm = new EmployeeViewModel();
            //vm.Employee = em;
            //vm.Title = "I am boy";
              //  return View(vm);
            //}
       // public ViewResult AllDetails()
        //{
          // List<Employee> gm = _IEmployeeRepo.GetAllEmployee();
            //return View(gm);
        //}
        [HttpGet]
        public ViewResult Create()
        {
            return View();
        }
        [HttpPost]

        public IActionResult Create(EmployeeViewModel model)
        {
            
            if (ModelState.IsValid)
            {
                string uniqueFileName = null;
                if (model.Photo != null)
                {
                    string uploadsFolder = Path.Combine(hostingEnvironment.WebRootPath, "Images");
                    uniqueFileName = Guid.NewGuid().ToString() + "_" + model.Photo.FileName;
                    string filePath = Path.Combine(uploadsFolder, uniqueFileName);
                    model.Photo.CopyTo(new FileStream(filePath, FileMode.Create));

                    
                }

                Employee employee = new Employee
                {
                    Name = model.Name,
                    Email = model.Email,
                    Department = model.Department,
                    PhotoPath = uniqueFileName
                };

                _IEmployeeRepo.Add(employee);



                return RedirectToAction("AllDetails");
            }
            return View();

        }
        public IActionResult Details(int Id)
        {
            Employee em = _IEmployeeRepo.GetEmployee(Id);
            return View(em);
        }

        public IActionResult Delete(int Id)
        {


            Employee em = _IEmployeeRepo.DeleteData(Id);
            return RedirectToAction("AllDetails"); 
        }

        public IActionResult AllDetails()
        {
            IEnumerable<Employee> em = _IEmployeeRepo.GetAllEmployee();
           // EmployeeViewModel vm = new EmployeeViewModel();
            
            return View(em);
        }
        [HttpGet]
        public IActionResult Edit(int Id)
        {
            Employee em = _IEmployeeRepo.GetEmployee(Id);
            EmployeeEditViewModel emVM = new EmployeeEditViewModel
            {
                Id = em.Id,
                Name = em.Name,
                Email = em.Email,
                Department = em.Department,
                ExistingPhotoPath = em.PhotoPath
            };
            return View(emVM);
        }

        [HttpPost]
        public IActionResult Edit(EmployeeEditViewModel model, int Id)
        {
            
            string uniqueFileName = null;
            string uploadsFolder = Path.Combine(hostingEnvironment.WebRootPath, "Images");
            uniqueFileName = Guid.NewGuid().ToString() + "_" + model.Photo.FileName;
            string filePath = Path.Combine(uploadsFolder, uniqueFileName);
            model.Photo.CopyTo(new FileStream(filePath, FileMode.Create));
            Employee employee = new Employee
            {
                Id = Id,
                Name = model.Name,
                Email = model.Email,
                Department = model.Department,
                PhotoPath = uniqueFileName
            };

            _IEmployeeRepo.Edit(employee);
            



            return RedirectToAction("AllDetails");

        }
       

        public ActionResult Foo()
        {
            return View();
        }
        }
    }

