﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EmployeeManagement.Models;
using EmployeeManagement.Repository.Implementation;
using EmployeeManagement.Repository.Interface;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace EmployeeManagement.Controllers
{
    public class DepartmentController : Controller
    {
       
        private readonly IDepartmentRepository _dmRepo;
        private readonly IHostingEnvironment hostingEnvironment;


        public DepartmentController(IDepartmentRepository IDepartmentRepo, IHostingEnvironment hostingEnvironment)
        {
           
            
            _dmRepo = IDepartmentRepo;
            this.hostingEnvironment = hostingEnvironment;

            // GET: /<controller>/
        }
        // GET: /<controller>/
        public IActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public ViewResult Create()
        {
            return View();
        }
        [HttpPost]
        public RedirectToActionResult Create(Department department)
        {

            Department dm = _dmRepo.Add(department);
            return RedirectToAction("Details", new { id = dm.Id });

        }
        public ViewResult Details(int id)
        {
          Department dm = _dmRepo.GetDepartment(id);
        return View(dm);
        }

    }
}
