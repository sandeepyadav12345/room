﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EmployeeManagement.Models;
using EmployeeManagement.Repository.Interface;
using EmployeeManagement.ViewModels;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace EmployeeManagement.Controllers
{
    public class HomeController : Controller
    {
        private IEmployeeRepository _empRepo;

        // Inject IEmployeeRepository using Constructor Injection
        public HomeController(IEmployeeRepository employeeRepository)
        {
            _empRepo = employeeRepository;
        }

        // GET: /<controller>/
       // public IActionResult Index()
        //{
        //   List<Employee> gm = _empRepo.GetAllEmployee();
         //   return View(gm);
            
            
        //}
        [HttpGet]
        public ViewResult Create()
        {
            return View();
        }
        [HttpPost]
        public RedirectToActionResult Create(Employee employee)
        {

            Employee emp = _empRepo.Add(employee);
            return RedirectToAction("Details", new { id = emp.Id });

        }
       // public ViewResult Details(int id)
        //{
          //  Employee em = _empRepo.GetEmployee(id);
            //return View(em);
        //}
    }
}
